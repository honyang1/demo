<template>
  <div>
    我是导航组件，有四个需要用到我，search不需要
  </div>
</template>